Follow below process to run project 

Unzip the Ayoconnect zip file and keep this folder in your go SRC folder

A)your_Go_Src/Ayoconnect
B)Go to Path -->Ayoconnect\Server\ 
C)go run main.go
// To Run each test case you need to visit respective folder eg:
// To Run robber case  \robber\
// Now Run go test 
// you will see the test case result 
 
D)To test, run command --> go test 
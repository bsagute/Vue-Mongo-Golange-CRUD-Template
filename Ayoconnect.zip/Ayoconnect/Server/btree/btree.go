package btree

import (
	"Ayoconnect/Server/queue"
	"fmt"
)

//BinaryTree - Modal  of BinaryTree
type BinaryTree struct {
	key         int
	leftChilds  *BinaryTree
	rightChilds *BinaryTree
}

//Tree - Modal of tree
type Tree struct {
	Root *BinaryTree
}

//NewBinaryTree - Function to create new BinaryTree
func NewBinaryTree(val int) *BinaryTree {
	BinaryTree := BinaryTree{
		key: val,
	}
	return &BinaryTree
}

//PreOrder - Function to Print the tree in preorder
func PreOrder(root *BinaryTree) {
	if root == nil {
		return
	}
	fmt.Println(" ", root.key)
	PreOrder(root.leftChilds)
	PreOrder(root.rightChilds)
}

//InOrder - Function to Print the elements in inorder
func InOrder(root *BinaryTree) {
	if root == nil {
		return
	}
	InOrder(root.leftChilds)
	fmt.Println(" ", root.key)
	InOrder(root.rightChilds)

}

//PostOrder - Function to Print the elements in postorder
func PostOrder(root *BinaryTree) {
	if root == nil {
		return
	}
	PostOrder(root.leftChilds)
	PostOrder(root.rightChilds)
	fmt.Print(" ", root.key)

}

//PrintPreOrder - Function to Print the elements in preorder
func PrintPreOrder(t *Tree) {
	fmt.Println("PRE-ORDER")
	if t.Root == nil {
		return
	}
	PreOrder(t.Root)
}

//PrintInOrder - Function to Print the tree in inorder
func PrintInOrder(t *Tree) {
	fmt.Println("IN-ORDER")
	if t.Root == nil {
		return
	}
	InOrder(t.Root)
}

//PrintPostOrder - Function to Print the tree in postorder
func PrintPostOrder(t *Tree) {
	fmt.Println("POST-ORDER")
	if t.Root == nil {
		return
	}
	PostOrder(t.Root)
}

//InsertKey - Method to insert in a binary tree in level order
func (t *Tree) InsertKey(val int) {
	newBinaryTree := NewBinaryTree(val)
	if t.Root == nil {
		t.Root = newBinaryTree
		return
	}
	var Que queue.Queue
	Que.EnQueue(t.Root)
	for !Que.IsEmpty() {
		var front *BinaryTree
		front = Que.GetFront().(*BinaryTree)
		Que.DeQueue()

		if front.leftChilds == nil {
			front.leftChilds = newBinaryTree
			return
		} else if front.rightChilds == nil {
			front.rightChilds = newBinaryTree
			return
		} else {
			Que.EnQueue(front.leftChilds)
			Que.EnQueue(front.rightChilds)
		}
	}

}

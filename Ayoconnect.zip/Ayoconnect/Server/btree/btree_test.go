package btree

import (
	"reflect"
	"testing"
)

func TestNewBinaryTree(t *testing.T) {
	type args struct {
		val int
	}
	tests := []struct {
		name string
		args args
		want *BinaryTree
	}{
		{
			name: "NewBinaryTree",
			args: args{
				val: 8,
			},
			want: &BinaryTree{
				key: 8,
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewBinaryTree(tt.args.val); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewBinaryTree() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestPreOrder(t *testing.T) {
	type args struct {
		root *BinaryTree
	}
	tests := []struct {
		name string
		args args
	}{
		{
			name: "PreOrder",
			args: args{
				root: &BinaryTree{
					key: 40,
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			PreOrder(tt.args.root)
		})
	}
}

func TestInOrder(t *testing.T) {
	type args struct {
		root *BinaryTree
	}
	tests := []struct {
		name string
		args args
	}{
		{
			name: "InOrder",
			args: args{
				root: &BinaryTree{
					key: 40,
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			InOrder(tt.args.root)
		})
	}
}

func TestPostOrder(t *testing.T) {
	type args struct {
		root *BinaryTree
	}
	tests := []struct {
		name string
		args args
	}{
		{
			name: "PostOrder",
			args: args{
				root: &BinaryTree{
					key: 40,
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			PostOrder(tt.args.root)
		})
	}
}

func TestPrintPreOrder(t *testing.T) {
	type args struct {
		t *Tree
	}
	tests := []struct {
		name string
		args args
	}{
		{
			name: "PrintPreOrder",
			args: args{
				t: &Tree{
					Root: &BinaryTree{
						key: 40,
					},
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			PrintPreOrder(tt.args.t)
		})
	}
}

func TestPrintPostOrder(t *testing.T) {
	type args struct {
		t *Tree
	}
	tests := []struct {
		name string
		args args
	}{
		{
			name: "PrintPostOrder",
			args: args{
				t: &Tree{
					Root: &BinaryTree{
						key: 40,
					},
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			PrintPostOrder(tt.args.t)
		})
	}
}
